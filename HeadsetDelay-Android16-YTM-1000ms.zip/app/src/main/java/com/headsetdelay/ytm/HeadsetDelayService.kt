package com.headsetdelay.ytm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.view.KeyEvent
import androidx.core.app.NotificationCompat

/**
 * خدمة النسخة الأولية لنظام Android 16 (API 36)
 * - تستهدف حزمة YouTube Music: com.google.android.apps.youtube.music
 * - تأخير قابل للتعديل من 500ms (0.5 ث) إلى 3000ms (3 ثوانٍ)
 * - التأخير الافتراضي: 1000ms (ثانية واحدة)
 * - الاستراتيجية الحالية: تأجيل وتمرير آخر أمر فقط (إلغاء الضغطات المكررة ضمن نافذة التأخير)
 */
class HeadsetDelayService : Service() {

    companion object {
        const val TARGET_YTM_PACKAGE = "com.google.android.apps.youtube.music"
        const val MIN_DELAY_MS = 500L
        const val MAX_DELAY_MS = 3000L
        const val DEFAULT_DELAY_MS = 1000L

        const val ACTION_UPDATE_CONFIG = "com.headsetdelay.ytm.UPDATE_CONFIG"
        const val EXTRA_DELAY_MS = "extra_delay_ms"
        const val EXTRA_ENABLED = "extra_enabled"
        private const val CHANNEL_ID = "headset_delay_channel"
        private const val NOTIFICATION_ID = 1601
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var mediaSession: MediaSession? = null
    private var pendingRunnable: Runnable? = null

    private var delayMs: Long = 1000L.coerceIn(MIN_DELAY_MS, MAX_DELAY_MS)
    private var isInterceptionEnabled: Boolean = true

    private lateinit var audioManager: AudioManager
    private lateinit var mediaSessionManager: MediaSessionManager
    private lateinit var powerManager: PowerManager

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        mediaSessionManager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildForegroundNotification())
        setupInterceptorMediaSession()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_UPDATE_CONFIG) {
            delayMs = intent.getLongExtra(EXTRA_DELAY_MS, DEFAULT_DELAY_MS)
                .coerceIn(MIN_DELAY_MS, MAX_DELAY_MS)
            isInterceptionEnabled = intent.getBooleanExtra(EXTRA_ENABLED, true)
            updateNotification()
        }
        return START_STICKY
    }

    private fun setupInterceptorMediaSession() {
        mediaSession = MediaSession(this, "HeadsetDelayYTMProxy").apply {
            setFlags(
                MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or
                    MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS
            )

            setPlaybackState(
                PlaybackState.Builder()
                    .setActions(
                        PlaybackState.ACTION_PLAY or
                            PlaybackState.ACTION_PAUSE or
                            PlaybackState.ACTION_PLAY_PAUSE or
                            PlaybackState.ACTION_SKIP_TO_NEXT or
                            PlaybackState.ACTION_SKIP_TO_PREVIOUS
                    )
                    .setState(PlaybackState.STATE_PAUSED, 0L, 1.0f)
                    .build()
            )

            setCallback(object : MediaSession.Callback() {
                override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                    val keyEvent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        mediaButtonIntent.getParcelableExtra(
                            Intent.EXTRA_KEY_EVENT,
                            KeyEvent::class.java
                        )
                    } else {
                        @Suppress("DEPRECATION")
                        mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT)
                    } ?: return super.onMediaButtonEvent(mediaButtonIntent)

                    if (keyEvent.action == KeyEvent.ACTION_DOWN) {
                        handleIncomingHeadsetKey(keyEvent)
                    }
                    return true
                }
            })

            isActive = true
        }
    }

    private fun handleIncomingHeadsetKey(keyEvent: KeyEvent) {
        if (!isInterceptionEnabled) {
            forwardToYouTubeMusic(keyEvent.keyCode)
            return
        }

        // إبقاء المعالج نشطاً مؤقتاً خلال نافذة التأخير (بحد أقصى 4 ثوانٍ)
        val wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "HeadsetDelay::DelayWindowLock"
        )
        wakeLock.acquire(MAX_DELAY_MS + 1000L)

        // إلغاء أي أمر سابق معلّق لتطبيق سياسة التأجيل ومنع الارتداد
        pendingRunnable?.let { mainHandler.removeCallbacks(it) }

        val task = Runnable {
            try {
                forwardToYouTubeMusic(keyEvent.keyCode)
            } finally {
                if (wakeLock.isHeld) {
                    wakeLock.release()
                }
            }
        }
        pendingRunnable = task
        mainHandler.postDelayed(task, delayMs)
    }

    /**
     * يحاول تمرير أمر زر السماعة إلى YouTube Music بعد انتهاء التأخير:
     * 1. عبر MediaController الخاص بحزمة com.google.android.apps.youtube.music
     * 2. كبديل احتياطي عبر AudioManager.dispatchMediaKeyEvent
     */
    private fun forwardToYouTubeMusic(keyCode: Int) {
        val listenerComponent = ComponentName(this, MediaNotificationBridge::class.java)
        val activeSessions: List<MediaController> = try {
            mediaSessionManager.getActiveSessions(listenerComponent)
        } catch (_: SecurityException) {
            emptyList()
        }

        val ytmController = activeSessions.firstOrNull {
            it.packageName == TARGET_YTM_PACKAGE
        }

        if (ytmController != null) {
            val controls = ytmController.transportControls
            when (keyCode) {
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                KeyEvent.KEYCODE_HEADSETHOOK -> {
                    val isPlaying = ytmController.playbackState?.state == PlaybackState.STATE_PLAYING
                    if (isPlaying) controls.pause() else controls.play()
                }
                KeyEvent.KEYCODE_MEDIA_PLAY -> controls.play()
                KeyEvent.KEYCODE_MEDIA_PAUSE -> controls.pause()
                KeyEvent.KEYCODE_MEDIA_NEXT -> controls.skipToNext()
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> controls.skipToPrevious()
                else -> dispatchFallbackMediaKey(keyCode)
            }
            return
        }

        // محاولة التمرير البديلة عبر نظام الصوت عند عدم توفر جلسة نشطة
        dispatchFallbackMediaKey(keyCode)
    }

    private fun dispatchFallbackMediaKey(keyCode: Int) {
        // تعطيل الجلسة المعترضة لحظياً لمنع الحلقة التكرارية أثناء إعادة التوجيه
        mediaSession?.isActive = false
        val now = SystemClock.uptimeMillis()
        audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
        audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0))
        mainHandler.postDelayed({ mediaSession?.isActive = true }, 120L)
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "خدمة تأخير زر السماعة",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildForegroundNotification(): Notification {
        val status = if (isInterceptionEnabled) {
            "نشط · تأخير ${delayMs}ms نحو YouTube Music"
        } else {
            "متوقف مؤقتاً"
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("مُرحّل السماعة لـ YouTube Music")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildForegroundNotification())
    }

    override fun onDestroy() {
        pendingRunnable?.let { mainHandler.removeCallbacks(it) }
        mediaSession?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

class MediaNotificationBridge : NotificationListenerService()
