package com.headsetdelay.ytm

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlin.math.roundToLong

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* تم التعامل مع إذن الإشعارات */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MaterialTheme {
                HeadsetDelayPrototypeScreen(
                    initialDelayMs = 1000L,
                    initialEnabled = true,
                    onApplyConfig = { delayMs, enabled ->
                        val intent = Intent(this, HeadsetDelayService::class.java).apply {
                            action = HeadsetDelayService.ACTION_UPDATE_CONFIG
                            putExtra(HeadsetDelayService.EXTRA_DELAY_MS, delayMs)
                            putExtra(HeadsetDelayService.EXTRA_ENABLED, enabled)
                        }
                        startForegroundService(intent)
                    },
                    onOpenNotificationAccess = {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }
                )
            }
        }
    }
}

@Composable
fun HeadsetDelayPrototypeScreen(
    initialDelayMs: Long,
    initialEnabled: Boolean,
    onApplyConfig: (Long, Boolean) -> Unit,
    onOpenNotificationAccess: () -> Unit
) {
    var delayMs by remember { mutableLongStateOf(initialDelayMs) }
    var serviceEnabled by remember { mutableStateOf(initialEnabled) }

    LaunchedEffect(Unit) {
        onApplyConfig(delayMs, serviceEnabled)
    }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = "مُرحّل السماعة — Android 16",
                style = MaterialTheme.typography.headlineSmall
            )
            Text(
                text = "التطبيق المستهدف: YouTube Music (com.google.android.apps.youtube.music)",
                style = MaterialTheme.typography.bodyMedium
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("تفعيل تأخير زر السماعة")
                Switch(
                    checked = serviceEnabled,
                    onCheckedChange = {
                        serviceEnabled = it
                        onApplyConfig(delayMs, serviceEnabled)
                    }
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = String.format("التأخير الحالي: %.1f ثانية (%d ms)", delayMs / 1000f, delayMs),
                    style = MaterialTheme.typography.titleMedium
                )
                Slider(
                    value = delayMs.toFloat(),
                    onValueChange = { raw ->
                        val snapped = (raw / 100f).roundToLong() * 100L
                        delayMs = snapped.coerceIn(
                            HeadsetDelayService.MIN_DELAY_MS,
                            HeadsetDelayService.MAX_DELAY_MS
                        )
                    },
                    onValueChangeFinished = {
                        onApplyConfig(delayMs, serviceEnabled)
                    },
                    valueRange = 500f..3000f,
                    steps = 24
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("0.5 ث", style = MaterialTheme.typography.labelSmall)
                    Text("1.0 ث (افتراضي)", style = MaterialTheme.typography.labelSmall)
                    Text("3.0 ث", style = MaterialTheme.typography.labelSmall)
                }
            }

            OutlinedButton(
                onClick = {
                    delayMs = HeadsetDelayService.DEFAULT_DELAY_MS
                    onApplyConfig(delayMs, serviceEnabled)
                }
            ) {
                Text("إعادة الضبط إلى الافتراضي (1.0 ثانية)")
            }

            Button(onClick = onOpenNotificationAccess) {
                Text("منح إذن الوصول للوسائط (YouTube Music)")
            }
        }
    }
}
